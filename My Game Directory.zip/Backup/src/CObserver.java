public interface CObserver {
    public void update(Character character);
}
