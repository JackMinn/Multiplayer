package Server;

import java.net.InetAddress;

public class World {
	Character[] characters;
	
	public World(InetAddress IPOfPlayer) {
		//we will do stuff
		System.out.println(IPOfPlayer);
	}

}
