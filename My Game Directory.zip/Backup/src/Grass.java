
public class Grass extends Scenery{

	public Grass(int x_loc, int y_loc) {
		super(x_loc, y_loc, "Grass");
		
	}

}

